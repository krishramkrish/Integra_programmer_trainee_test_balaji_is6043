var mysql = require('mssql');
var express = require('express');
var app = express();
var con = mysql.createConnection({
    host: "localhost",
    user: "username",
    password: "dbpassword",
    database: "mydb" //database name
});

app.post('/savePaymentInfo', function (req, res) {
    firstname = req.body.firstname,
        emailname = req.body.emailname,
        pass = req.body.pass,
        dob = req.body.dob,
        gender = req.body.gender,
        paymentmode = req.body.paymentmode,
        card = req.body.card,
        cvv = req.body.cvv,
        cvvmy = req.body.cvvmy

    con.connect(function (err) {
        if (err) throw err;
        var sql = "INSERT INTO paymentDetails VALUES (" + firstname + "," + emailname + "," + pass + "," + dob + "," + gender + "," + paymentmode + "," + card + "," + cvv + "," + cvvmy + "," + Date() + ");";
        con.query(sql, function (err, result) {
            if (err) throw err;
            console.log(result.affectedRows + " record(s) inserted successfully");
        });
    });
});

var server = app.listen(8081, function () {
    var host = server.address().address
    var port = server.address().port
    console.log("Example app listening at http://%s:%s", host, port)
})